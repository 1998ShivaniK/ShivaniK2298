﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class ItemDetails : System.Web.UI.Page
{
   int id = 0;
    SqlConnection con;

 
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
        Label2.Visible = false;
        Label3.Visible = false;
      // TextBox6.Visible = false;
       autoIncrement();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into ItemM values('" + TextBox1.Text + "'," + TextBox2.Text + ",'" +DropDownList1.SelectedItem.Text+ "','" + TextBox3.Text + "'," + TextBox4.Text + "," + TextBox5.Text + ")", con);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            txtclear();
           autoIncrement();
           Label1.Visible = true;
  
        }
    }

    private void autoIncrement()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select max(ItemId) from ItemM ", con);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            id = int.Parse(rd[0].ToString()) + 1;
            TextBox2.Text = id.ToString();

        }
        rd.Dispose();
        cmd.Dispose();
        con.Close();
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select * from ItemM where itemname ='" + TextBox3.Text + "'", con);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
               
            TextBox6.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();

            TextBox2.Text = rd[1].ToString();
            DropDownList1.SelectedItem.Text= rd[2].ToString();
            TextBox4.Text = rd[4].ToString();
            TextBox5.Text = rd[5].ToString();
        }
        rd.Dispose();
        cmd.Dispose();
        con.Close();
        TextBox6.Visible = true;
        TextBox1.Visible = false;

    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        TextBox1.Visible = true;
        TextBox6.Visible = false;
    }

    protected void btnupdate_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("update ItemM set itemname='" + TextBox3.Text + "',orderprice=" + TextBox4.Text + ",stock=" + TextBox5.Text + ", date='" + DateTime.Parse(TextBox6.Text ).Date.ToShortDateString() + "' where Itemid=" + TextBox2.Text + " ", con);
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();
        autoIncrement();
        Label2.Visible = true;
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Delete from ItemM where Itemid=" +TextBox2.Text + " ", con);
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();
        autoIncrement();
        Label3.Visible = true;
    }
    private void txtclear()
    {
       TextBox3.Text= "";
       TextBox4.Text = "";
       TextBox5.Text = "";
       
    }

}