﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Registration : System.Web.UI.Page
{
    int id = 0;
    SqlConnection con;

    protected void Page_Load(object sender, EventArgs e)
    {
        Label9.Visible = false;
        autoIncrement();

    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Registration values(" + TextBox1.Text + ",'" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','"+ TextBox6.Text + "','" + TextBox7.Text + "')", con);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            txtclear();
            autoIncrement();
            Response.Write("Registered Successfully");
            Response.Redirect("~/CustomerL.aspx");

        }
    }
    private void autoIncrement()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select max(id) from Registration", con);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            id = int.Parse(rd[0].ToString()) + 1;
            TextBox1.Text = id.ToString();

        }
        rd.Dispose();
        cmd.Dispose();
        con.Close();
    }

    private void txtclear()
    {
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
    }

   
}