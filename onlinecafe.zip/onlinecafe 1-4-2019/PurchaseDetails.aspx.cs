﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class PurchaseDetails : System.Web.UI.Page
{
    int id = 0, sum = 0;
    SqlConnection con;
    SqlCommand cmd ,cmd1,cmd2;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
        autoIncrement();
     //   TextBox7.Visible = false;
    }
    protected void btnadd_Click(object sender, EventArgs e)
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into purchase values('" + TextBox1.Text + "'," + TextBox2.Text + ",'" + TextBox3.Text + "','" + TextBox4.Text + "'," + TextBox5.Text + "," + TextBox6.Text + "," + TextBox8.Text + ")", con);
        cmd.ExecuteNonQuery();
        Label1.Visible = true;
        cmd.Dispose();

        SqlCommand cmd3 = new SqlCommand("update ItemM set stock= stock + " + int.Parse(TextBox6.Text) + " where itemname='" + TextBox4.Text + "' ", con);
        cmd3.ExecuteNonQuery();
        cmd3.Dispose();
        con.Close();
      //  txtclear();
        autoIncrement();

        //con.Open();
        //SqlCommand cmd1 = new SqlCommand("select * from SupplierM where supname='" + TextBox3.Text  + "'", con);
        //SqlDataReader rd = cmd.ExecuteReader();
        //while (rd.Read())
        //{
        //    TextBox3.Text = rd[2].ToString();
        //}
        //rd.Dispose();
        //cmd1.Dispose();
        //con.Close();
        ////SqlCommand cmd2 = new SqlCommand("select * from ItemM where itemname='" + TextBox4.Text + "'", con);
    }

    }
    private void autoIncrement()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select max(Billno) from purchase", con);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            id = int.Parse(rd[0].ToString()) + 1;
            TextBox2.Text = id.ToString();
        }
        rd.Dispose();
        cmd.Dispose();
        con.Close();

    }


    protected void btnreset_Click(object sender, EventArgs e)
    {
        TextBox1.Visible = true;
        TextBox7.Visible = false;
    }
    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {
        int a, b;
        a = Convert.ToInt32(TextBox5.Text);
        b = Convert.ToInt32(TextBox6.Text);
        TextBox8.Text = (a * b).ToString();
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select * from purchase where supname ='" + TextBox3.Text + "'", con);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {

           TextBox7.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();
            TextBox2.Text = rd[1].ToString();
            TextBox4.Text = rd[3].ToString();
            TextBox5.Text = rd[4].ToString();
            TextBox6.Text = rd[5].ToString();
            TextBox8.Text = rd[6].ToString();
        }
        rd.Dispose();
        cmd.Dispose();
        con.Close();
        TextBox7.Visible = true;
        TextBox1.Visible = false;


    }
}
