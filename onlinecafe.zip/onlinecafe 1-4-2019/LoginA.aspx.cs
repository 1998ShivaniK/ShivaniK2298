﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class LoginC : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblusermessage.Visible = false;
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
       // SqlConnection sqlCon = new SqlConnection(@"Data Source=.;Initial Catalog=OnlineCafe;Integrated Security=True;");

        {
            con.Open();
            string query = "SELECT COUNT(1) FROM LoginA WHERE username=@username AND password=@password";
            SqlCommand sqlCmd = new SqlCommand(query, con);
            sqlCmd.Parameters.AddWithValue("@username", textbox1.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@password", textbox2.Text.Trim());
            int count = Convert.ToInt32(sqlCmd.ExecuteScalar());
            if (count == 1)
            {
             //   btnlogin.OnClientClick = "<script LANGUAGE='JavaScript'>alert('Login Successful')</script>";
              Response.Write("<script LANGUAGE='JavaScript'>alert('Login Successful')</script>");
              //Response.Redirect("~/Additems.aspx");
            }
            else
            {
                lblusermessage.Visible = true;
            }
        }
    }
    
}