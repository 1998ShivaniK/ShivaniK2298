﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class CutomerL : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label4.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Registration where Email='" + TextBox1.Text  + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                if(TextBox2.Text.Trim() ==rd[6].ToString().Trim()   )
                {
                    Label4.Visible = true;
                }
            }
            Response.Redirect("index.aspx");

            rd.Dispose();
            cmd.Dispose();
            con.Close();
        }
    }
}
