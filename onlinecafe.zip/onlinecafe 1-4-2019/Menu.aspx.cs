﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Menu : System.Web.UI.Page
{
    int id = 0;
    SqlConnection con;

    protected void Page_Load(object sender, EventArgs e)
    {
        autoIncrement();
    }
    protected void btncustomsearch_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
           // Response.Write(TextBox11.Text);
            SqlCommand cmd = new SqlCommand("Select * from Registration where Name='" + TextBox11.Text + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                //TextBox6.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();
                TextBox10.Text = rd[0].ToString();
                TextBox12.Text = rd[2].ToString();
                TextBox13.Text = rd[3].ToString();
            }
            rd.Dispose();

            cmd.Dispose();
            con.Close();


        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ItemM where itemname ='" + TextBox2.Text + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {

              //  TextBox6.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();

                TextBox1.Text = rd[1].ToString();
                TextBox3.Text = rd[4].ToString();
              //  TextBox4.Text = rd[5].ToString();
            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
        }
    }
  
    protected void btnorder_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into orderT values('" + TextBox5.Text + "'," + TextBox16.Text + "," + TextBox10.Text + ",'" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "'," + TextBox1.Text + ",'" + TextBox2.Text + "'," + TextBox3.Text + "," + TextBox4.Text + "," + TextBox14.Text + ")", con);
            cmd.ExecuteNonQuery();
            cmd.Dispose();

            SqlCommand cmd3 = new SqlCommand("update ItemM set stock= stock - " + int.Parse(TextBox4.Text) + " where itemname='" + TextBox2.Text + "' ", con);
            cmd3.ExecuteNonQuery();
            cmd3.Dispose();
            con.Close();
            //  txtclear();
            autoIncrement();
           // Response.Redirect("Success");
         Response.Redirect("order.aspx");

        }
   
    }
    private void autoIncrement()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("Select max(Billno) from orderT ", con);
        SqlDataReader rd = cmd.ExecuteReader();
        while (rd.Read())
        {
            id = int.Parse(rd[0].ToString()) + 1;
            TextBox16.Text = id.ToString();

        }
        rd.Dispose();
        cmd.Dispose();
        con.Close();
    }

    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {
        int a, b,c,d;
        a = Convert.ToInt32(TextBox3.Text);
        b = Convert.ToInt32(TextBox4.Text);
        TextBox14.Text = (a * b).ToString();
        //int price=Convert.ToInt32(TextBox3.Text);
        //int quantity = Convert.ToInt32(TextBox3.Text);
        //int mul = quantity * price;
        //TextBox14.Text = mul.ToString();
        Label2.Text = "";
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        
            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select * from ItemM where itemname ='" + TextBox2.Text + "'", con);
            SqlDataReader rd1 = cmd1.ExecuteReader();
            while (rd1.Read())
            {
                c = Convert.ToInt32(rd1[5].ToString());
                d = Convert.ToInt32(TextBox4.Text);
                if( c <= d )
                {
                    Label2.Text = "Out Of Stock..!";
                    TextBox4.Text = "";
                    TextBox14.Text = "";
                }
            }
            rd1.Dispose();
            cmd1.Dispose();
            con.Close();
    }
    protected void btnsearch2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ItemM where itemname ='" + TextBox7.Text + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {

                //  TextBox6.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();

                TextBox1.Text = rd[1].ToString();
                TextBox3.Text = rd[4].ToString();
                //  TextBox4.Text = rd[5].ToString();
            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
        }
    }

    protected void btnsearch2_Click1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ItemM where itemname ='" + TextBox7.Text + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {

              //  TextBox6.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();

                TextBox6.Text = rd[1].ToString();
                TextBox8.Text = rd[4].ToString();
              //  TextBox4.Text = rd[5].ToString();
            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
        }
    }
    protected void TextBox9_TextChanged(object sender, EventArgs e)
    {
        int a, b,c,d;
        a = Convert.ToInt32(TextBox8.Text);
        b = Convert.ToInt32(TextBox9.Text);
        TextBox15.Text = (a * b).ToString();

        Label3.Text = "";
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);

        con.Open();
        SqlCommand cmd1 = new SqlCommand("Select * from ItemM where itemname ='" + TextBox7.Text + "'", con);
        SqlDataReader rd1 = cmd1.ExecuteReader();
        while (rd1.Read())
        {
            c = Convert.ToInt32(rd1[5].ToString());
            d = Convert.ToInt32(TextBox9.Text);
            if (c <= d)
            {
                Label3.Text = "Out Of Stock..!";
                TextBox9.Text = "";
                TextBox15.Text = "";
            }
        }
        rd1.Dispose();
        cmd1.Dispose();
        con.Close();
    }
    protected void btnsearch3_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ItemM where itemname ='" + TextBox23.Text + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {

                //  TextBox6.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();

                TextBox22.Text = rd[1].ToString();
                TextBox24.Text = rd[4].ToString();
                //  TextBox4.Text = rd[5].ToString();
            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
        }

    }
    protected void TextBox25_TextChanged(object sender, EventArgs e)
    {
        int a, b;
        a = Convert.ToInt32(TextBox24.Text);
        b = Convert.ToInt32(TextBox25.Text);
        TextBox26.Text = (a * b).ToString();

    }
    protected void btnsearch5_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ItemM where itemname ='" + TextBox28.Text + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {

                //  TextBox6.Text = DateTime.Parse(rd[0].ToString()).Date.ToShortDateString();

                TextBox27.Text = rd[1].ToString();
                TextBox29.Text = rd[4].ToString();
                //  TextBox4.Text = rd[5].ToString();
            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
        }
    }

    protected void TextBox30_TextChanged(object sender, EventArgs e)
    {
        int a, b;
        a = Convert.ToInt32(TextBox29.Text);
        b = Convert.ToInt32(TextBox30.Text);
        TextBox31.Text = (a * b).ToString();
    }
    protected void btnordr2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        {
            con.Open();
            SqlCommand cmd4 = new SqlCommand("insert into orderT values('" + TextBox5.Text + "'," + TextBox16.Text + "," + TextBox10.Text + ",'" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox13.Text + "'," + TextBox6.Text + ",'" + TextBox7.Text + "'," + TextBox8.Text + "," + TextBox9.Text + "," + TextBox15.Text + ")", con);
            cmd4.ExecuteNonQuery();
            cmd4.Dispose();

            SqlCommand cmd3 = new SqlCommand("update ItemM set stock= stock - " + int.Parse(TextBox9.Text) + " where itemname='" + TextBox7.Text + "' ", con);
            cmd3.ExecuteNonQuery();
            cmd3.Dispose();
            con.Close();
            //  txtclear();
            autoIncrement();
            Response.Redirect("order.aspx");

        }
    }
}
