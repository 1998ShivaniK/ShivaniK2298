﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BakeryMs
{
    public partial class Login : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Bakerysk;Integrated Security=True");
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;
            label2.Parent = pictureBox1;
            label2.BackColor = Color.Transparent;
            label3.Parent = pictureBox1;
            label3.BackColor = Color.Transparent;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = ("select * from LoginMastr where Username='" + textBox1.Text.ToString() + "' and Password='" + textBox2.Text.ToString() + "'");
            SqlCommand cmd1 = new SqlCommand(sql,con);
           // cmd1 = new SqlCommand(sql, con);
           // con.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd1.ExecuteReader());
            con.Close();
            if (dt.Rows.Count == 1)
            {
                MessageBox.Show("Login Sucsessfull", "LOGIN");
                Home h = new Home();
                h.Show();
                this.Hide();
            }
            else
            {
               // MessageBox.Show("somthing went wrong", "Input Error");
               // login l = new login();
                //l.Show();
              //  this.Hide();
            }


            if (textBox1.Text.Trim(' ').Length == 0)
            {
                MessageBox.Show("Please enter correct Username and Password", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Focus();
                return;
            }
            if (textBox2.Text.Trim(' ').Length == 0)
            {
                MessageBox.Show("Please enter correct  Username and Password", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Focus();
                return;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
