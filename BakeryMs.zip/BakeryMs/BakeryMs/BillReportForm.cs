﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace BakeryMs
{
    public partial class BillReportForm : Form
    {
        public BillReportForm()
        {
            InitializeComponent();
        }

        private void BillReportForm_Load(object sender, EventArgs e)
        {
             int id=0;
           SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Bakerysk;Integrated Security=True");
           con.Open();
            SqlCommand cmd = new SqlCommand("Select max(SalesBillNo) from SaleTable ", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                id = int.Parse(rd[0].ToString()) ;
               
                //MessageBox.Show(int.Parse(rd[0].ToString()));
            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();

            ReportDocument cryRpt = new ReportDocument();
            cryRpt.Load(@"C:\Users\Kasar\Documents\Visual Studio 2013\Projects\BakeryMs\BakeryMs\Bill.rpt");
            crystalReportViewer1.ReportSource = cryRpt;
            crystalReportViewer1.SelectionFormula = " {SaleTable.SalesBillNo} =" + id  + " ";
            crystalReportViewer1.Refresh();

            /*ReportDocument cryRpt = new ReportDocument();
              cryRpt.Load(@"C:\Users\Kasar\Documents\Visual Studio 2013\Projects\BakeryMs\BakeryMs\Bill.rpt");
              crystalReportViewer1.ReportSource = cryRpt;
               crystalReportViewer1.Refresh();*/
            
        }
    }
}
