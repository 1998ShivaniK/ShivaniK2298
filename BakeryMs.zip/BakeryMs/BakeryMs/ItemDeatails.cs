﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BakeryMs
{
    public partial class ItemDeatails : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Bakerysk;Integrated Security=True");
        int id = 0;
        string style = null;

        public ItemDeatails()
        {
            InitializeComponent();
        }

        private void ItemDeatails_Load(object sender, EventArgs e)
        {
            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;
            label3.BackColor = Color.Transparent;
            label4.BackColor = Color.Transparent;
            label5.BackColor = Color.Transparent;
            label6.BackColor = Color.Transparent;
            label7.BackColor = Color.Transparent;
                      style = null;
             txtclear();
            listBox1.Visible = false;
            cmdInsert.Enabled = true;
            cmdUpdate.Enabled = false;
            cmdDelete.Enabled = false;
            autoIncrement();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            style = null;
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ItemMasters where Itemname='" + listBox1.SelectedItem + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                textBox1.Text = rd[0].ToString();
                textBox2.Text = rd[1].ToString();
                textBox3.Text = rd[2].ToString();
                textBox4.Text = rd[3].ToString();
                textBox5.Text = rd[4].ToString();
                dateTimePicker1.Text = rd[5].ToString();
            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
            cmdUpdate.Enabled = true;
            cmdDelete.Enabled = true;
            listBox1.Visible = false;
        }
        private void txtclear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void autoIncrement()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select max(ItemId) from ItemMasters ", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {

                id = int.Parse(rd[0].ToString()) + 1;
                textBox1.Text = id.ToString();
   //MessageBox.Show(int.Parse(rd[0].ToString()));

            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
            textBox2.Focus();
            textBox1.Enabled = false;
        }


        private void cmdInsert_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Please Fill All Fields");

            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into ItemMasters values(" + textBox1.Text + ",'" + textBox2.Text + "'," + textBox3.Text + "," + textBox4.Text + "," + textBox5.Text + ",'" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Inserted");
                cmd.Dispose();
                con.Close();
                 txtclear();
                autoIncrement();

            }

        }

        private void cmdUpdate_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "")
            {
                MessageBox.Show("Please Fill All Fields");

            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update ItemMasters set Itemname='" + textBox2.Text + "',Purchaseprice=" + textBox3.Text + ",Saleprice=" + textBox4.Text + ",Stock=" + textBox5.Text + ", date='" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") + "' where Itemid=" + textBox1.Text + " ", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                cmd.Dispose();
                con.Close();
                txtclear();
                cmdInsert.Enabled = true;
                cmdUpdate.Enabled = false;
                cmdDelete.Enabled = false;
                autoIncrement();
            }
        }

        private void cmdDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(" Delete from ItemMasters where Itemid=" + textBox1.Text + " ", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted");
            cmd.Dispose();
            con.Close();
            txtclear();
            cmdInsert.Enabled = true;
            cmdUpdate.Enabled = false;
            cmdDelete.Enabled = false;
            autoIncrement();
        }

        private void cmdReset_Click(object sender, EventArgs e)
        {
             txtclear();
            cmdInsert.Enabled = true;
            cmdUpdate.Enabled = false;
            cmdDelete.Enabled = false;
            autoIncrement();
            textBox2.Focus();
        }

        private void cmdSearch_Click(object sender, EventArgs e)
        {
             style = "search";
            textBox1.Enabled = false;
            textBox2.Focus();
            cmdInsert.Enabled = false;
            cmdUpdate.Enabled = true;
            cmdDelete.Enabled = true;
            txtclear();
            listBox1.Visible = false;
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();


            if (style == "search")
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ItemMasters where Itemname like '" + textBox2.Text + "%'", con);
                SqlDataReader rd = cmd.ExecuteReader();
                listBox1.Visible = false;
                while (rd.Read())
                {
                    listBox1.Visible = true;
                    listBox1.Items.Add(rd[1].ToString());

                }

                rd.Dispose();
                cmd.Dispose();
                con.Close();
            }
            if (textBox2.Text == "")
            {
                listBox1.Visible = false;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back))
            {

                MessageBox.Show("please enter Character only");
                e.Handled = true;
            }

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                MessageBox.Show("please enter digits only");
                e.Handled = true;
            }
 }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                MessageBox.Show("please enter digits only");
                e.Handled = true;
            }

        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                MessageBox.Show("please enter digits only");
                e.Handled = true;
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            textBox2.BackColor = System.Drawing.Color.Pink;
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            textBox3.BackColor = System.Drawing.Color.Pink;
        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            textBox4.BackColor = System.Drawing.Color.Pink;
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            textBox5.BackColor = System.Drawing.Color.Pink;
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            textBox2.BackColor = System.Drawing.Color.White;
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            textBox4.BackColor = System.Drawing.Color.White;
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            textBox5.BackColor = System.Drawing.Color.White;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        }


}

    


