﻿namespace BakeryMs
{
    partial class Itemreport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.BakeryskDataSet = new BakeryMs.BakeryskDataSet();
            this.ItemMastersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ItemMastersTableAdapter = new BakeryMs.BakeryskDataSetTableAdapters.ItemMastersTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.BakeryskDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemMastersBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.DocumentMapWidth = 85;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.ItemMastersBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "BakeryMs.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 60);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(676, 373);
            this.reportViewer1.TabIndex = 0;
            // 
            // BakeryskDataSet
            // 
            this.BakeryskDataSet.DataSetName = "BakeryskDataSet";
            this.BakeryskDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ItemMastersBindingSource
            // 
            this.ItemMastersBindingSource.DataMember = "ItemMasters";
            this.ItemMastersBindingSource.DataSource = this.BakeryskDataSet;
            // 
            // ItemMastersTableAdapter
            // 
            this.ItemMastersTableAdapter.ClearBeforeFill = true;
            // 
            // Itemreport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 468);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Itemreport";
            this.Text = "Itemreport";
            this.Load += new System.EventHandler(this.Itemreport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BakeryskDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemMastersBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource ItemMastersBindingSource;
        private BakeryskDataSet BakeryskDataSet;
        private BakeryskDataSetTableAdapters.ItemMastersTableAdapter ItemMastersTableAdapter;

    }
}