﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BakeryMs
{
    public partial class Purchase_Details : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Bakerysk;Integrated Security=True");
        string style = null;
        int id = 0, sum = 0;
        public Purchase_Details()
        {
            InitializeComponent();
        }

        private void cmdSubmit_Click(object sender, EventArgs e)
        {
            //  if (textBox2.Text == "" && textBox6.Text == "")
            {
                con.Open();
                for (int rows = 0; rows < dataGridView1.Rows.Count - 1; rows++)
                {
                    // for insert PurchaseDetails
                    SqlCommand cmd = new SqlCommand("insert into PurchaseDetails values(" + textBox1.Text + ",'" + dataGridView1.Rows[rows].Cells[0].Value.ToString() + "'," + dataGridView1.Rows[rows].Cells[1].Value.ToString() + "," + dataGridView1.Rows[rows].Cells[2].Value.ToString() + "," + dataGridView1.Rows[rows].Cells[3].Value.ToString() + ") ", con);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    //for Update stock
                    SqlCommand cmd1 = new SqlCommand("update ItemMasters set Purchaseprice=" + dataGridView1.Rows[rows].Cells[1].Value.ToString() + ",Stock= Stock + " + (int.Parse(dataGridView1.Rows[rows].Cells[2].Value.ToString())) + ", date='" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") + "' where Itemname='" + dataGridView1.Rows[rows].Cells[0].Value.ToString() + "' ", con);
                    cmd1.ExecuteNonQuery();
                    cmd1.Dispose();
                }
                // for insert PurchaseTable
                SqlCommand cmd2 = new SqlCommand("insert into PurchaseTable values(" + textBox1.Text + ",'" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") + "'," + textBox7.Text + "," + textBox6.Text + ")", con);
                cmd2.ExecuteNonQuery();
                MessageBox.Show("Record Inserted","Alert");
                cmd2.Dispose();
                con.Close();
                txtclear();
                autoIncrement();
                cmdSubmit.Enabled = false;
            }
            //   else
            {
                //        MessageBox.Show("Please Enter Supplier Name");
            }
        }

        private void Purchase_Details_Load(object sender, EventArgs e)
        {
            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;
            label3.BackColor = Color.Transparent;
            label4.BackColor = Color.Transparent;
            label5.BackColor = Color.Transparent;
            label6.BackColor = Color.Transparent;
            label7.BackColor = Color.Transparent;
            label8.BackColor = Color.Transparent;
            style = null;
            txtclear();
            //  listBox1.Visible = false;
            // cmdInsert.Enabled = true;
            //cmdUpdate.Enabled = false;
            //cmdDelete.Enabled = false;
            autoIncrement();
            textBox2.Focus();
            cmdSubmit.Enabled = false;
            listBox1.Visible = false;
        }
        private void txtclear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox1.Enabled = false;
            textBox6.Enabled = false;
            dataGridView1.Rows.Clear();

        }
        private void autoIncrement()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select max(Billno) from PurchaseTable ", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                id = int.Parse(rd[0].ToString()) + 1;
                textBox1.Text = id.ToString();


                //MessageBox.Show(int.Parse(rd[0].ToString()));

            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
            textBox2.Focus();
            textBox1.Enabled = false;
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            if (style == "supplier")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from SupplierMaster where supname like '" + textBox2.Text + "%'", con);
                SqlDataReader rd = cmd.ExecuteReader();
                listBox1.Visible = false;
                while (rd.Read())
                {
                    listBox1.Visible = true;
                    listBox1.Items.Add(rd[1].ToString());
                }

                rd.Dispose();
                cmd.Dispose();
                con.Close();
            }

            if (textBox2.Text == "")
            {
                listBox1.Visible = false;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back))
            {

                MessageBox.Show("please enter Character only");
                e.Handled = true;
            }
            style = "supplier";
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back))
            {

                MessageBox.Show("please enter Character only");
                e.Handled = true;
            }
            style = "item";
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                MessageBox.Show("please enter digits only");
                e.Handled = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            if (style == "item")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ItemMasters where Itemname like '" + textBox3.Text + "%'", con);
                SqlDataReader rd = cmd.ExecuteReader();
                listBox1.Visible = false;
                while (rd.Read())
                {
                    listBox1.Visible = true;
                    listBox1.Items.Add(rd[1].ToString());
                }
                rd.Dispose();
                cmd.Dispose();
                con.Close();
            }
            if (textBox3.Text == "")
            {
                listBox1.Visible = false;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (style == "supplier")
            {
                style = null;
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from SupplierMaster where supname='" + listBox1.SelectedItem + "'", con);
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    textBox7.Text = rd[0].ToString();
                    textBox2.Text = rd[1].ToString();
                }
                rd.Dispose();
                cmd.Dispose();
                con.Close();
                //cmdUpdate.Enabled = true;
                // cmdDelete.Enabled = true;
                listBox1.Visible = false;
                textBox3.Focus();
            }
            if (style == "item")
            {
                style = null;
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from ItemMasters where Itemname='" + listBox1.SelectedItem + "'", con);
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    textBox3.Text = rd[1].ToString();
                    textBox4.Text = rd[2].ToString();
                }
                rd.Dispose();
                cmd.Dispose();
                con.Close();
                //cmdUpdate.Enabled = true;
                // cmdDelete.Enabled = true;
                listBox1.Visible = false;
                textBox5.Focus();
            }
        }

        private void cmdAddItem_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "" && textBox5.Text != "")
            {
                string[] row = new string[] { textBox3.Text, textBox4.Text, textBox5.Text, (int.Parse(textBox4.Text) * int.Parse(textBox5.Text)).ToString() };
                sum = sum + (int.Parse(textBox4.Text) * int.Parse(textBox5.Text));
                textBox6.Text = sum.ToString();
                dataGridView1.Rows.Add(row);
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox3.Focus();
                cmdSubmit.Enabled = true;
            }
            else
            {
                MessageBox.Show("Please Fill Item Deatils");
            }
        }

        private void cmdReset_Click(object sender, EventArgs e)
        {
            txtclear();
            autoIncrement();
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                MessageBox.Show("please enter digits only");
                e.Handled = true;
            }
        }




    }
}
