﻿namespace BakeryMs
{
    partial class Cust
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.BakeryskDataSet = new BakeryMs.BakeryskDataSet();
            this.CustomerMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.CustomerMasterTableAdapter = new BakeryMs.BakeryskDataSetTableAdapters.CustomerMasterTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.BakeryskDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerMasterBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.CustomerMasterBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "BakeryMs.Report2.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(29, 47);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(542, 369);
            this.reportViewer1.TabIndex = 0;
            // 
            // BakeryskDataSet
            // 
            this.BakeryskDataSet.DataSetName = "BakeryskDataSet";
            this.BakeryskDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // CustomerMasterBindingSource
            // 
            this.CustomerMasterBindingSource.DataMember = "CustomerMaster";
            this.CustomerMasterBindingSource.DataSource = this.BakeryskDataSet;
            // 
            // CustomerMasterTableAdapter
            // 
            this.CustomerMasterTableAdapter.ClearBeforeFill = true;
            // 
            // Cust
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 471);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Cust";
            this.Text = "Stocks";
            this.Load += new System.EventHandler(this.Stocks_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BakeryskDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerMasterBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource CustomerMasterBindingSource;
        private BakeryskDataSet BakeryskDataSet;
        private BakeryskDataSetTableAdapters.CustomerMasterTableAdapter CustomerMasterTableAdapter;

    }
}