﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BakeryMs
{
    public partial class Customer : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Bakerysk;Integrated Security=True");
        int id = 0;
        string style = null;

        public Customer()
        {
            InitializeComponent();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;
            label2.Parent = pictureBox1;
            label2.BackColor = Color.Transparent;
            label3.Parent = pictureBox1;
            label3.BackColor = Color.Transparent;
            label4.Parent = pictureBox1;
            label4.BackColor = Color.Transparent;
            label5.Parent = pictureBox1;
            label5.BackColor = Color.Transparent;


            style = null;
             txtclear();
            listBox1.Visible = false;
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
           autoIncrement();

           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Please Fill All Fileds");
                return;
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into CustomerMaster values(" + textBox1.Text + ",'" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')", con);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Inserted", "Alert");
                cmd.Dispose();
                con.Close();
                txtclear();
                autoIncrement();

            }



        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (textBox4.Text.Length <= 9)
            {
                MessageBox.Show("Please Enter 10 Digit Mobile No.");
                textBox4.Text = "";
                textBox4.Focus();
                return;
            }
            
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Please Fill All Fileds");
                return;
            }
            else
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update CustomerMaster set custname='" + textBox2.Text + "',custaddress='" + textBox3.Text + "',custmno= '" + textBox4.Text + "' where id=" + textBox1.Text + " ", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated","Alert");
                cmd.Dispose();
                con.Close();
               
                
                txtclear();
                button1.Enabled = true;
                button2.Enabled = false;
                button3.Enabled = false;
              autoIncrement();
            }
        
        }
        private void txtclear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox2.BackColor = System.Drawing.Color.White;
            textBox3.BackColor = System.Drawing.Color.White;
            textBox4.BackColor = System.Drawing.Color.White;

        }
        private void autoIncrement()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select max(id) from CustomerMaster ", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                id = int.Parse(rd[0].ToString()) + 1;
                textBox1.Text = id.ToString();

            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
            textBox2.Focus();
            textBox1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(" Delete from CustomerMaster where id=" + textBox1.Text + " ", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Deleted" ,"Alert");
            cmd.Dispose();
            con.Close();
            txtclear();
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            autoIncrement();
       
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            style = null;
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from CustomerMaster where custname='" + listBox1.SelectedItem + "'", con);
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                textBox1.Text = rd[0].ToString();
                textBox2.Text = rd[1].ToString();
                textBox3.Text = rd[2].ToString();
                textBox4.Text = rd[3].ToString();

            }
            rd.Dispose();
            cmd.Dispose();
            con.Close();
            button2.Enabled = true;
            button3.Enabled = true;
            listBox1.Visible = false;
            textBox2.Focus();
 }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                MessageBox.Show("Please enter digits only");
                e.Handled = true;
            }

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back))
            {

                MessageBox.Show("Please enter Character only");
                e.Handled = true;
            }
      
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /* con.Open();
           SqlCommand cmd = new SqlCommand("Select * from s where name='"+textBox2.Text +"'", con);
           SqlDataReader rd = cmd.ExecuteReader();
           while (rd.Read())
           {
               textBox1.Text = rd[0].ToString();
               textBox3.Text = rd[2].ToString();
               textBox4.Text = rd[3].ToString();

           }
           rd.Dispose();
           cmd.Dispose();
           con.Close();*/
            style = "search";
            textBox1.Enabled = false;
            textBox2.Focus();
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;
            txtclear();
            listBox1.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                MessageBox.Show("please enter digits only");
                e.Handled = true;
            }
        
            textBox4.BackColor = System.Drawing.Color.White;
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            textBox2.BackColor = System.Drawing.Color.Pink;
  
        }

        private void textBox3_Enter(object sender, EventArgs e)
        {
            textBox3.BackColor = System.Drawing.Color.Pink;
    
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.BackColor = System.Drawing.Color.Pink;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            
            
            if(style=="search")
            {
                                                       
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from CustomerMaster where custname like '" + textBox2.Text + "%'", con);
                SqlDataReader rd = cmd.ExecuteReader();
                listBox1.Visible = false;
                while (rd.Read())
                {
                    listBox1.Visible = true;

                    listBox1.Items.Add(rd[1].ToString ());

                }
                
                rd.Dispose();
                cmd.Dispose();
                con.Close();
            }
            if (textBox2.Text == "")
            {
                listBox1.Visible = false;
            }
        }
    }
}
